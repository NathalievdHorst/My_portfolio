<?php
    include("include/functions.php"); 
    $category = getProjectCategory();
?>
<!DOCTYPE html>
<html>
    <head>
        <title>MyPortfolio</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <!--set Favicon image icon-->
	    <link rel="icon" href="images/Nathalie.png" type="image/x-icon"/> 
        <link rel="stylesheet" type="text/css" href="css/style.css">
    </head>

    <body>

        <?php
            include'include/HTMLhead.php';
        ?>

        <div class="main-container">
            <div class="project-container">
                <h3><?php echoCategoryName(); ?></h3>
                <ul id="project">
                    <?php
                        foreach($category as $key => $cat) //loop for project items
                        {
                    ?>
                    <li>
                        <div class="project-item">
                        <a href="detailproject.php?ProjectId=<?php echo $cat["ProjectId"];?>">
						    <img id="image" src="images/<?php echo $cat["ProjectImage"];?>">
					    </a>                        
                        <div class="name"><?php echo $cat['ProjectName'];?></div>
                        <div class="category"><?php echo $cat['ProjectCategoryTitle'];?></div>
                        </li>    
                    <?php        
                        }                      
                    ?>  
                </ul>      
                </div>
            </div>
        </div>

        <div class="footer">
            <?php
                include'include/HTMLfoot.php';
            ?>
	    </div>

    </body>
    
</html>