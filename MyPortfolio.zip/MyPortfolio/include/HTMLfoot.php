<footer id="footer">
    <p>
        © Nathalie van der Horst<br>
        <a href="mailto:83393@roc-teraa.nl">83393@roc-teraa.nl</a><br>
        +31636034415
    </p>
</footer>