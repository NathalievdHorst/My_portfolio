
<header id="header">
    <div><a href="index.php"><img id="logo" src="images/nathalie.png"></a></div>

    <nav class="navbar-inverse">
        <div class="container-fluid">
            <div class="navbar-header">
            <a class="navbar-brand" href="index.php">MyPortfolio</a>
            </div>
            <ul class="nav navbar-nav">
            <li class="active"><a href="index.php">Home</a></li>
            <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="">Projects <span class="caret"></span></a>
                <ul class="dropdown-menu"><!--dropdown menu items-->
                <li><a href="projects.php?ProjectCategoryId=">All Projects</a></li>
                <li><a href="projects.php?ProjectCategoryId=1">Webdevelopment</a></li>
                <li><a href="projects.php?ProjectCategoryId=2">Application</a></li>
                <li><a href="projects.php?ProjectCategoryId=3">Embedded Systems</a></li>
                <li><a href="projects.php?ProjectCategoryId=4">Industrial Automation</a></li>
                </ul>
            </li>
            <li><a href="about.php">About</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li><a href="links.php"> Favorite Links</a></li>
            </ul>
        </div>
    </nav>
</header>