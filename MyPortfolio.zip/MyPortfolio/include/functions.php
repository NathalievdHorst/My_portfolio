<?php
function connectDatabase()
{
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "myportfolio";
   

    //variable for the database connections
    $conn = new mysqli($servername, $username, $password, $dbname);

    $conn = mysqli_connect($servername, $username, $password, $dbname) or die(mysqli_error($conn));

    return $conn;
}

function contactConnect()
{
    if(isset($_POST['submit']))
    {
        // Load Composer's autoloader    
        require 'PHPMailer/PHPMailerAutoload.php';

        $mail = new PHPMailer;

        //SMTP Simple Mail Transfer Protocol
        $mail->isSMTP();                                      // Set mailer to use SMTP
        $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
        $mail->SMTPAuth = true;                               // Enable SMTP authentication
        $mail->Username = 'testphp83393@gmail.com';                 // SMTP username
        $mail->Password = '9KZNb26r!';                           // SMTP password
        $mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
        $mail->Port = 25;                                    // TCP port needs to be 25. in php.ini port is also initialized as 25 and they both need to be the same

        $mail->setFrom('testphp83393@gmail.com', 'Mailer'); 
        $mail->addAddress('testphp83393@gmail.com', 'Joe User');  //Email address where the message is sent to

        $mail->isHTML(true);                                  // Set email format to HTML

        $gender = "";
        if(isset($_POST['gender'] )) 
        { 
            $gender = $_POST['gender']; 
        }

        $mail->Subject = 'Message from customer';
        $mail->Body='<p>First Name: '.$_POST['firstname'].'<br>Last Name: '.$_POST['lastname']. '<br>Gender: '. $gender .'<br>Email: '.$_POST['email'].'<br>Message: '.$_POST['comment'].'</p>'; //get info from the name, mail en comment input to send in the mail
        
        $message = "Your message has been sent! We will strive to answer your mail within two workdays.";

   
        //if mail could not be send or one of the fields is empty echo message could not be send
        if(!$mail->send() ||  empty($_POST["firstname"]) || empty($_POST["lastname"])  || empty($_POST["gender"]) || empty($_POST["email"]) || empty($_POST["comment"])) 
        {
            echo 'Message could not be sent. ';
        } 
        else 
        {
            echo "<script type='text/javascript'>alert('$message');</script>";
        }
    }
}


function getProjectCategory()
{

    $conn = connectDatabase();

    //define an empty array to store projects
    $category = array();

    if(isset($_GET["ProjectCategoryId"])) //checks in the url of projectCategoryId exists, it is declared and different then NULL
    {
        $projectCategoryId = $_GET["ProjectCategoryId"]; //Hyperlink to the projects page using a GET parameter
    }
    else
    {
        $projectCategoryId = "";
    }

    //define the query to fetch data from the database 
    $getCategorySQL = "SELECT * FROM `projects`, `projectcategory` WHERE `projectcategory` .`ProjectCategoryId` = `projects` .`ProjectCategoryId`";
   
    if(isset($projectCategoryId) && $projectCategoryId != "")  //!= means it cant be equal""
    {
        $getCategorySQL.= " AND `projectcategory` .`ProjectCategoryId` = ".$projectCategoryId.""; //if we have a category id it will add it to our if statement
    }
    
    //perform query on $conn and store resource
    $resource = mysqli_query($conn, $getCategorySQL) or die(mysqli_error($conn));

    while($row = mysqli_fetch_assoc($resource))//gives an associative array and puts it in category
    {
        //add new items to $category
        $category[] = $row;
    }

    return $category;
}


function getDetailProject()
{
    $conn = connectDatabase();

    //define an empty array to store projects
    $detail = array();
    
    if(isset($_GET["ProjectId"])) //checks in the url of projectCategoryId exists, it is declared and different then NULL
    {
        $detailId  = $_GET["ProjectId"]; //Hyperlink to the projects page using a GET parameter
    }
    else
    {
        $detailId  = "";
    }

    //define the query to fetch data from the database
    $detailSQL = "SELECT * FROM `projects`, `projectcategory` WHERE `projectcategory` .`ProjectCategoryId` = `projects` .`ProjectCategoryId` ";

    if(isset($detailId) && $detailId != "")  //!= means it cant be equal""
    {
        $detailSQL.= "AND `Projects`.`ProjectId` = ".$detailId."";  //if we have a category id it will add it to our if statement
    }

    $resource = mysqli_query($conn, $detailSQL) or die(mysqli_error($conn)); 
    $detail = mysqli_fetch_array($resource);
    

    return $detail; 
}

/*function that gives the project id a name*/
function btnName()
{
    if(isset($_GET["ProjectId"])) //checks in the url of projectCategoryId exists, it is declared and different then NULL
    {
        $projectId = $_GET["ProjectId"]; //Hyperlink to the projects page using a GET parameter
    }
    else
    {
        $projectId = "";
    }
    
    $btnLive="";
    if ($projectId == 1) 
    {
        $btnLive = "Calculator++";
    } 
    elseif ($projectId == 2) 
    {
        $btnLive = "Marvel Heroes"; 
    } 
    elseif ($projectId == 5) 
    {
        $btnLive = "GameWorld"; 
    }
    elseif ($projectId == 7) 
    {
        $btnLive = "Radio GaGa"; 
    }
    elseif ($projectId == 8) 
    {
        $btnLive = "SignUpSignIn"; 
    }
    elseif ($projectId == 11) 
    {
        $btnLive = "Vault Js"; 
    }
    
    echo $btnLive;
  
}

/*function that gets the project paths */
function btnPath() 
{
    if(isset($_GET["ProjectId"])) //checks in the url of projectCategoryId exists, it is declared and different then NULL
    {
        $projectId = $_GET["ProjectId"]; //Hyperlink to the projects page using a GET parameter
    }
    else
    {
        $projectId = "";
    }

    $btnP = true;
    $btnPath="";
    if ($projectId == 1) 
    {
        $btnPath = "'http://localhost/Old_projects_2019-2020/Nathalie_vanderHorst_calcplusplus/calculator++.php','_blank'";    
    } 
    elseif ($projectId == 2) 
    {
        $btnPath = "'http://localhost/DCHeroes/Nathalie_vanderHorst_DCHeroes/','_blank'";
    } 
    elseif ($projectId == 5) 
    {
        $btnPath = "'http://localhost/Old_projects_2019-2020/gameworld/Nathalie_vanderHorst_Gameworld/','_blank'"; 
        $btnP = true;
    }
    elseif ($projectId == 7) 
    {
        $btnPath = "'http://localhost/Old_projects_2019-2020/radiogaga/radiogaga/','_blank'";       
    }
    elseif ($projectId == 8) 
    {
        $btnPath = "'http://localhost/Old_projects_2019-2020/SignUpSignIn/SignUpSignIn/','_blank'"; 
    }
    elseif ($projectId == 11) 
    {
        $btnPath = "'http://localhost/Old_projects_2019-2020/Nathalie_vanderHorst_VaultJS/','_blank'"; 
    }
    

    echo $btnPath;
   
}


function echoCategoryName()
{
    if(isset($_GET["ProjectCategoryId"])) //checks in the url of projectCategoryId exists, it is declared and different then NULL
    {
        $projectCategoryId = $_GET["ProjectCategoryId"]; //Hyperlink to the projects page using a GET parameter
    }
    else
    {
        $projectCategoryId = "";
    }
    
    $categoryName="";
    if ($projectCategoryId == 1) 
    {
        $categoryName = "Webdevelopment";
    } 
    elseif ($projectCategoryId == 2) 
    {
        $categoryName = "Application";
    } 
    elseif ($projectCategoryId == 3) 
    {
        $categoryName = "Embedded Systems";
    }
    elseif ($projectCategoryId == 4) 
    {
        $categoryName = "Industrial Automation";
    }
    else
    {
        $categoryName = "Projects";
    }

    echo $categoryName;
}

function insertContact()
{
    $conn = connectDatabase();

    if(isset($_POST["submit"])) //execute when something is set
    {
        if(!$conn) //it will check if there is a connection if not than die
        {
            die("Could not connect: " . mysqli_error());
        }
        else
        {    
            $errors = [];   
            $firstName = $_POST["firstname"]; //variables to get the input values of the form to add to the database
            $firstName = trim($firstName); //removes all white space at the beginning and end of a variable 
            $firstName = mysqli_real_escape_string($conn, $firstName); //(improved version of above variable)

            $lastName = $_POST["lastname"];
            $lastName = trim($lastName);
            $lastName= mysqli_real_escape_string($conn, $lastName);

            $gender = "";
            if(isset($_POST['gender'] )) 
            { 
                $gender = $_POST['gender']; 
            }
            $gender = trim($gender);
            $gender = mysqli_real_escape_string($conn, $gender);

            $email = $_POST["email"];
            $email = trim($email);
            $email = mysqli_real_escape_string($conn, $email);

            $comment = $_POST["comment"];
            $comment = trim($comment);
            $comment = mysqli_real_escape_string($conn, $comment);
   
            if(empty($_POST["firstname"]))
            {
                $errors[] = "Fill in your firstname"; 
            }
            if(empty($_POST["lastname"]))
            {
                $errors[] = "Fill in your lastname"; 
            }
            if(empty($_POST["gender"]))
            {
                $errors[] = "Select gender"; 
            }
            if(empty($_POST["email"]))
            {
                $errors[] = "Fill in your email"; 
            }
            if(empty($_POST["comment"]))
            {
                $errors[] = "Fill in your comment"; 
            }

            if(count($errors) == 0)
            {
                $query = "INSERT INTO `contact` (`FirstName`, `LastName`, `Gender`, `Email`, `Message`) 
                VALUES ('$firstName', '$lastName', '$gender', '$email' , '$comment');";
                mysqli_query($conn, $query);
    
            }
            else 
            {
                //foreach loop to show the errors if fields empty
                foreach($errors as $value)
                {
                    echo $value . ", ";
                }
            }
        
        }
    }
}

//function download resume
function resume() 
{
    $file = "downloads/Nathalie-van-der-Horst-Resume.docx";
    header("Pragma: public", true);
    header("Expires: 0"); // set expiration time
    header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
    header("Content-Type: application/force-download");
    header("Content-Type: application/octet-stream");
    header("Content-Type: application/download");
    header("Content-Disposition: attachment; filename=".basename($file));
    header("Content-Transfer-Encoding: binary");
    header("Content-Length: ".filesize($file));
    die(file_get_contents($file));    
}

//checks if the productid is there if not return fals so no button will appear
function CheckExample()
{
    if(isset($_GET["ProjectId"])) //checks in the url of projectCategoryId exists, it is declared and different then NULL
    {
        $projectId = $_GET["ProjectId"]; //Hyperlink to the projects page using a GET parameter
    }
    else
    {
        $projectId = "";
    }

    if ($projectId == 1) 
    {
        return true;
    } 
    elseif ($projectId == 2) 
    {
        return true; 
    } 
    elseif ($projectId == 5) 
    {
        return true;
    }
    elseif ($projectId == 7) 
    {
        return true;
    }
    elseif ($projectId == 8) 
    {
        return true;
    }
    elseif ($projectId == 11) 
    {
        return true;
    }
    else 
    {
        return false;
    }
}

?>