<?php
    include("include/functions.php"); 
?>
<!DOCTYPE html>
<html>
    <head>
        <title>MyPortfolio</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <!--set Favicon image icon-->
	    <link rel="icon" href="images/Nathalie.png" type="image/x-icon"/> 
        <link rel="stylesheet" type="text/css" href="css/style.css">
    </head>

    <body>
        <?php
            include'include/HTMLhead.php';
        ?>

        <div class="main-container">
            <div class="container">
                <h3>About</h3>
                <p>My name is Nathalie van der Horst and I currently live in Helmond where I go to school to learn how to program. Download my resume if you would like to know a little more about me!</p>
                <h4>Skills</h4>
                <p>Event Planning, Communication, Teamwrok, Organization, Punctuality</p>
                <h4>Certificates</h4>
                <p>Microsoft Office Word, Excel, Powerpoint Specialist 2016</p>
                <h4>Education</h4>
                <p>HAVO NG Dr.Knippenbergcollege Helmond, Life Science Hogeschool Utrecht, Optometry Hogeschool Utrecht, Applicatie Media ontwikkelaar ROC ter AA Helmond</p>
                <h4>Languages</h4>
                <p>Dutch, English, Vietnamese</P>
                <h4>Hobbies</h4>
                <p>Gaming, Cooking, Movies</p>
                <h4>Resume</h4>
                <button class="button">
                    <a href="downloads/Nathalie-van-der-Horst-Resume.docx">Download</a>
                </button>
            </div>  

        </div>
        <div class="footer">
            <?php
                include'include/HTMLfoot.php';
            ?>
        </div>
    </body>
       
    
</html>