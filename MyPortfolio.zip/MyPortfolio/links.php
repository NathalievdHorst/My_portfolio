<!DOCTYPE html>
<html>
    <head>
        <title>MyPortfolio</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <!--set Favicon image icon-->
	    <link rel="icon" href="images/Nathalie.png" type="image/x-icon"/> 
        <link rel="stylesheet" type="text/css" href="css/style.css">
    </head>

    <body>

        <?php
            include'include/HTMLhead.php';
        ?>

        <div class="main-container">
            <div class="container">
                <h3>Link</h3>
                <p><a href="https://www.w3schools.com/bootstrap/bootstrap_navbar.asp">
                    W3schools Bootstrap nav
                </a></p>
                <p><a href="https://www.w3schools.com/bootstrap/bootstrap_carousel.asp">
                    W3schools Bootstrap carousel
                </a></p>
                <p><a href="https://bootsnipp.com/snippets/XRNAv">
                    Typewriter effect
                </a></p>
            </div>        
        </div>

        <div class="footer">
            <?php
                include'include/HTMLfoot.php';
            ?>
	    </div>

    </body>
    
</html>