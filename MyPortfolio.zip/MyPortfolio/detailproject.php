<?php
    include("include/functions.php"); 
    $detail = getDetailProject();  
?>

<!DOCTYPE html>
<html>
    <head>
        <title>MyPortfolio</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <!--set Favicon image icon-->
	    <link rel="icon" href="images/Nathalie.png" type="image/x-icon"/> 
        <link rel="stylesheet" type="text/css" href="css/style.css">
    </head>

    <body>
        <?php
            include'include/HTMLhead.php';
        ?>

        <div class="main-container">
            
            <div id="detailContainer">
                <img class="imgDetail" src="images/<?php echo $detail["ProjectImage"];?>">
                <div class="title"><?php echo $detail['ProjectName'];?></div>
                <div class="description"><?php echo $detail['ProjectDescription'];?></div>
                <div id="property">Properties</div>
                <div class="description"><?php echo $detail['ProjectCategoryDescription'];?></div>
                <?php if(CheckExample())
                {?>
                <button  class="button" onclick=" window.open(<?php btnPath();  ?>)"><?php btnName(); ?></button>                   
                <?php
                }
                ?>
            </div>  
            
        </div>
        <div class="footer">
            <?php
                include'include/HTMLfoot.php';
            ?>
        </div>
    </body>
       
    
</html>