<?php
    include("include/functions.php"); 
    $category = getProjectCategory();
?>

<!DOCTYPE html>
<html>
<head>

	<title>MyPortfolio</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!--bootstrap-->	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	<link rel="icon" href="images/Nathalie.png" type="image/x-icon"/> 
	<!--css style sheet-->
	<link rel="stylesheet" type="text/css" href="css/style.css">

</head>
<body>
	<!--include for header navigation-->
	<?php
        include'include/HTMLhead.php';
    ?>

	<div class="main-container">
	
		<h1>
			<a href="projects.php" class="typewrite" data-period="2000" data-type='[ "Hi, I am Nathalie.", "Welcome to MyPortfolio." ]'>
				<span class="wrap"></span>
			</a>
		</h1>
		
		<div id="myCarousel" class="carousel slide" data-ride="carousel ">
			
			<!-- Wrapper for slides -->
			<div class="carousel-inner">
				
				<div class="item active">
					<img src="images/welcome.png" alt="">
					<div class="carousel-caption">
					</div>
				</div>

				<?php
					foreach($category as $key => $cat)
					{
				?>
				<div class="item">
					<img id="image" src="images/<?php echo $cat["ProjectImage"];?>">
					<div class="carousel-caption">
						<h3><?php echo $cat['ProjectName'];?></h3>
						<p><?php echo $cat['ProjectCategoryTitle'];?></p>
						
					</div>	
				</div>
				<?php        
					}                      
				?> 

			</div>

			<!-- Left and right controls -->
			<a class="left carousel-control" href="#myCarousel" data-slide="prev">
				<span class="glyphicon glyphicon-chevron-left"></span>
				<span class="sr-only">Previous</span>
			</a>
			<a class="right carousel-control" href="#myCarousel" data-slide="next">
				<span class="glyphicon glyphicon-chevron-right"></span>
				<span class="sr-only">Next</span>
			</a>
		</div>

		<!-- Indicators -->
		<ol class="carousel-indicators">
				<li data-target="#myCarousel" data-slide-to="0" class="active"></li>
				<li data-target="#myCarousel" data-slide-to="1"></li>
				<li data-target="#myCarousel" data-slide-to="2"></li>
				<li data-target="#myCarousel" data-slide-to="3"></li>
				<li data-target="#myCarousel" data-slide-to="4"></li>
				<li data-target="#myCarousel" data-slide-to="5"></li>
				<li data-target="#myCarousel" data-slide-to="6"></li>
				<li data-target="#myCarousel" data-slide-to="7"></li>
				<li data-target="#myCarousel" data-slide-to="8"></li>
				<li data-target="#myCarousel" data-slide-to="9"></li>
				<li data-target="#myCarousel" data-slide-to="10"></li>
				<li data-target="#myCarousel" data-slide-to="11"></li>
				<li data-target="#myCarousel" data-slide-to="12"></li>
				<li data-target="#myCarousel" data-slide-to="13"></li>
				<li data-target="#myCarousel" data-slide-to="14"></li>
				<li data-target="#myCarousel" data-slide-to="15"></li>
			</ol>
		
	</div>
	<!--include for footer-->
	<div class="footer">
		<?php
			include'include/HTMLfoot.php';
		?>
	</div>
	<script type="text/javascript" src="js/main.js"></script>
</body>
</html>  

