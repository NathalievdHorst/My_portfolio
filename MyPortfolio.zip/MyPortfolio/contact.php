<?php
    include("include/functions.php"); 
?>

<!DOCTYPE html>
<html>
<head>
    <title>MyPortfolio</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <!--set Favicon image icon-->
	<link rel="icon" href="images/Nathalie.png" type="image/x-icon"/> 
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
    <?php
        include'include/HTMLhead.php';
    ?>
    <div class="main-container">
            <div class="message"> 
                <?php
                    contactConnect(); 
                    insertContact();
                ?>
            </div>  
       
            <div class="banner">
                <h1>Contact</h1>
                <p>If you have any questions please send me a message.</p>
            </div>
                <form id="form" action="contact.php" method="POST">
                    <ul>    
                        <li>
                            <label>First Name</label>
                        </li>
                        <li>
                            <input class="formInput" type="text" name="firstname" value="">
                        </li>
                        <li>
                            <label>Last Name</label>
                        </li>
                        <li>           
                            <input class="formInput" type="text" name="lastname" value="">
                        </li>
                        <li>
                            <label>
                                Gender
                            </label>
                        </li>      
                        <li>
                            <input type="radio" name="gender" value="Male">
                            <label>Male</label>
                            
                            <input type="radio" name="gender" value="Female">
                            <label>Female</label>
                            
                            <input type="radio" name="gender" value="Other">
                            <label>Other</label>
                        </li>
                        <li>
                            <label>E-mail</label>
                        </li>
                        <li>
                            <input class="formInput" type="email" name="email" value="">
                        </li>
                        <li>
                            <label>Your Message</label>
                        </li>
                        <li>
                            <textarea name="comment"></textarea>
                        </li>
                        <li>
                            <input class="button" type="submit" name="submit" value="Send">                     
                        </li>
                    </ul>
                </form>             
    </div>
    <div class="footer">
        <?php
            include'include/HTMLfoot.php';
        ?>
    </div>

</body>
</html>